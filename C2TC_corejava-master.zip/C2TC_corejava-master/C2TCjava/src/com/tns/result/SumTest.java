
package com.tns.result;
import com.tns.calculate.*;

public class SumTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
     Sum s = new Sum ();
     s.cal ();
	}

}
